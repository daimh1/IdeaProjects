package homework02;

public interface Passive {
    void abc(int num);
}
